#include<stdlib.h>
#include<stdio.h>
#include<stddef.h>
#include<stdbool.h>
#include "stabilitytest.h"
#include "global.h"

int  main(int argv, char *argc[]){
printf("%f",lower.L);

struct dynamic_vals test1;

test1.theta[0] <- 0.0;
test1.theta[1] <- 45.0;
test1.thetad[0] <- 0.0;
test1.thetad[1] <- 0.0;
test1.thetadd[0] <- 0.0;
test1.thetadd[1] <- 0.0;
test1.alpha2 <- 0.0;
test1.omega2 <- 0.0;

    return 0;
}
